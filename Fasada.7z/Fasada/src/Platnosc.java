public class Platnosc {
    public void przetwarzajPlatnosc(String metodaPlatnosci) {
        System.out.println("Przetwarzanie płatności przez: " + metodaPlatnosci + "...");
    }
}
