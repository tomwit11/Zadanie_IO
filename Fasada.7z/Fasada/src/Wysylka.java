public class Wysylka {
    public void wyslij(String adres) {
        System.out.println("Wyślij do: " + adres + "...");
    }
}
