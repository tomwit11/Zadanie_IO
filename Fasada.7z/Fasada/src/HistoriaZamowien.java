import java.util.ArrayList;
import java.util.List;

public class HistoriaZamowien {
    private final List<String> historiaZamowien = new ArrayList<>();

    public void dodajZamowienie(String szczegolyZamowienia) {
        historiaZamowien.add(szczegolyZamowienia);
        System.out.println("Dodanie zamówienia do historii: " + szczegolyZamowienia);
    }

    public void pokazHistorieZamowien() {
        System.out.println("Historia zamówień: " + historiaZamowien.toString());
    }
}
