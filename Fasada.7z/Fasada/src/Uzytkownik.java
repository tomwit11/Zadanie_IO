public class Uzytkownik {
    private final String adres;
    private final String metodaPlatnosci;

    public Uzytkownik(String nazwaUzytkownika, String adres, String metodaPlatnosci) {
        this.adres = adres;
        this.metodaPlatnosci = metodaPlatnosci;
    }

    public String getAdres() {
        return adres;
    }

    public String getMetodaPlatnosci() {
        return metodaPlatnosci;
    }
}
