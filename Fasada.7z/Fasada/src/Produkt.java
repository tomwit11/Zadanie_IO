public class Produkt {
    private final String nazwaProduktu;
    private int zapas;

    public Produkt(String nazwaProduktu, int zapas) {
        this.nazwaProduktu = nazwaProduktu;
        this.zapas = zapas;
    }

    public void sprawdzDostepnosc() {
        if(zapas > 0) {
            System.out.println("Produkt " + nazwaProduktu + " jest dostępny.");
        } else {
            System.out.println("Produkt " + nazwaProduktu + " jest niedostępny.");
        }
    }

    public void zmniejszIlosc() {
        if(zapas > 0) {
            zapas--;
            System.out.println("Produkt dodany do koszyka. Pozostała ilość: " + zapas);
        }
    }
}
