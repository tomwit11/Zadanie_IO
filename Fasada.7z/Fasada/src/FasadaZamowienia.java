public class FasadaZamowienia {
    private final Produkt produkt;
    private final Platnosc platnosc;
    private final Wysylka wysylka;
    private final Uzytkownik kontoUzytkownika;
    private final HistoriaZamowien historiaZamowien;

    public FasadaZamowienia(Produkt produkt, Uzytkownik kontoUzytkownika, HistoriaZamowien historiaZamowien) {
        this.produkt = produkt;
        this.platnosc = new Platnosc();
        this.wysylka = new Wysylka();
        this.kontoUzytkownika = kontoUzytkownika;
        this.historiaZamowien = historiaZamowien;
    }

    public void zlozZamowienie() {
        produkt.sprawdzDostepnosc();
        produkt.zmniejszIlosc();
        platnosc.przetwarzajPlatnosc(kontoUzytkownika.getMetodaPlatnosci());
        wysylka.wyslij(kontoUzytkownika.getAdres());
        historiaZamowien.dodajZamowienie("Zamówienie produktu: " + produkt);
    }
}
