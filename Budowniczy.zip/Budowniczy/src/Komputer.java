class Komputer {

    private final String procesor;
    private final String kartaGraficzna;
    private final String RAM;
    private final String pamiec;
    private final String systemChlodzenia;
    private final String zasilacz;
    private final String obudowa;

    private Komputer(KomputerBudowniczy budowniczy) {
        this.procesor = budowniczy.procesor;
        this.kartaGraficzna = budowniczy.kartaGraficzna;
        this.RAM = budowniczy.RAM;
        this.pamiec = budowniczy.pamiec;
        this.systemChlodzenia = budowniczy.systemChlodzenia;
        this.zasilacz = budowniczy.zasilacz;
        this.obudowa = budowniczy.obudowa;
    }

    public static class KomputerBudowniczy {
        private final String procesor;
        private final String kartaGraficzna;
        private String RAM;
        private String pamiec;
        private String systemChlodzenia;
        private String zasilacz;
        private String obudowa;

        public KomputerBudowniczy(String procesor, String kartaGraficzna) {
            this.procesor = procesor;
            this.kartaGraficzna = kartaGraficzna;
        }

        public KomputerBudowniczy ustawRAM(String RAM) {
            this.RAM = RAM;
            return this;
        }

        public KomputerBudowniczy ustawPamiec(String pamiec) {
            this.pamiec = pamiec;
            return this;
        }

        public KomputerBudowniczy ustawSystemChlodzenia(String systemChlodzenia) {
            this.systemChlodzenia = systemChlodzenia;
            return this;
        }

        public KomputerBudowniczy ustawZasilacz(String zasilacz) {
            this.zasilacz = zasilacz;
            return this;
        }

        public KomputerBudowniczy ustawObudowe(String obudowa) {
            this.obudowa = obudowa;
            return this;
        }

        public Komputer buduj() {
            return new Komputer(this);
        }
    }

    @Override
    public String toString() {
        return "Komputer {" +
                " procesor='" + procesor + '\'' +
                ", karta graficzna='" + kartaGraficzna + '\'' +
                ",RAM='" + RAM + '\'' +
                ", pamięć='" + pamiec + '\'' +
                ", system chłodzenia='" + systemChlodzenia + '\'' +
                ", zasilacz='" + zasilacz + '\'' +
                ", obudowa='" + obudowa + '\'' +
                '}';
    }
}
