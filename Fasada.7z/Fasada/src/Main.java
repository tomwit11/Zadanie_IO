public class Main {
    public static void main(String[] args) {
        Produkt produkt = new Produkt("Laptop Dell", 10);
        Uzytkownik kontoUzytkownika = new Uzytkownik("Tomek98", "123 Ulica, Miasto", "PayPal");
        HistoriaZamowien historiaZamowien = new HistoriaZamowien();

        FasadaZamowienia fasadaZamowienia = new FasadaZamowienia(produkt, kontoUzytkownika, historiaZamowien);
        fasadaZamowienia.zlozZamowienie();

        historiaZamowien.pokazHistorieZamowien();
    }
}