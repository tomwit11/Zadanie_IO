public class SklepKomputerowy {

    public static void main(String[] args) {
        Klient klient = new Klient("Michał Nowak");

        Komputer niestandardowyKomputer = new Komputer.KomputerBudowniczy("Intel Core i9", "NVIDIA RTX 3090")
                .ustawRAM("32GB")
                .ustawPamiec("2TB SSD")
                .ustawSystemChlodzenia("Chłodzeniecieczą")
                .ustawZasilacz("750W")
                .ustawObudowe("Obudowa z podświetleniem RGB")
                .buduj();

        Zamowienie zamowienie = new Zamowienie(klient, niestandardowyKomputer);
        zamowienie.zlozZamowienie();

        System.out.println(zamowienie.pokazSzczegolyZamowienia());
    }
}
