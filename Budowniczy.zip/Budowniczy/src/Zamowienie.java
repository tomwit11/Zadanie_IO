class Zamowienie {
    private final String idZamowienia;
    private final Klient klient;
    private final Komputer komputer;
    private boolean czyZlozone;

    public Zamowienie(Klient klient, Komputer komputer) {
        this.idZamowienia = java.util.UUID.randomUUID().toString();
        this.klient = klient;
        this.komputer = komputer;
    }

    public void zlozZamowienie() {
        this.czyZlozone = true;
    }

    public String pokazSzczegolyZamowienia() {
        return "ID Zamówienia: " + idZamowienia + "\nKlient: " + klient.pokazImie() + "\nZamówiony Komputer: " + komputer.toString() + "\nStatus Zamówienia: " + (czyZlozone ? "Złożone" : "Nie złożone");
    }
}