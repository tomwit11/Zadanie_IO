class Klient {
    private final String imie;

    public Klient(String imie) {
        this.imie = imie;
    }

    public String pokazImie() {
        return imie;
    }
}